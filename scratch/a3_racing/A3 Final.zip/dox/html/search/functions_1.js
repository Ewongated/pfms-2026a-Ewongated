var searchData=
[
  ['euclidean_109',['euclidean',['../namespacegeom.html#ae773072e51f054eb2f6483a0a5ad232a',1,'geom']]]
];
