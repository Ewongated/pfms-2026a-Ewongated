var searchData=
[
  ['newodom_51',['newOdom',['../classLaserProcessing.html#a7f5df80f1a0c657213c40221d5bd7483',1,'LaserProcessing']]],
  ['newscan_52',['newScan',['../classLaserProcessing.html#ad3230e5cf34ce2bdce92dcf96baf497a',1,'LaserProcessing']]]
];
