var searchData=
[
  ['control_5fhz_135',['CONTROL_HZ',['../classRacingNode.html#a31c49111dfb98172439e9840746c1f44',1,'RacingNode']]],
  ['controlthread_5f_136',['controlThread_',['../classRacingNode.html#a216226cbd8bdad72dbc31618e8facc43',1,'RacingNode']]],
  ['corner_5falpha_5frad_137',['CORNER_ALPHA_RAD',['../classRacingNode.html#a404e7884ffab19d59e4247bc14fb0cdb',1,'RacingNode']]],
  ['corner_5fbrake_138',['CORNER_BRAKE',['../classRacingNode.html#a8ee01f8eb393031af3b4eeeffe76b54e',1,'RacingNode']]],
  ['corridor_5ftolerance_5fm_139',['CORRIDOR_TOLERANCE_M',['../classLaserProcessing.html#a0d663af81ad8f2295bfebdcde5abe58a',1,'LaserProcessing']]],
  ['cruise_5flookahead_5fdist_5fm_140',['CRUISE_LOOKAHEAD_DIST_M',['../classRacingNode.html#af9006c9fc4e3ee25a512599308aa3014',1,'RacingNode']]],
  ['cruise_5fthrottle_141',['CRUISE_THROTTLE',['../classRacingNode.html#af5153644986667dd0b4c8026a29dd9fd',1,'RacingNode']]],
  ['currentgoal_5f_142',['currentGoal_',['../classRacingNode.html#af04fe621b83ad7c549d56fa760265e07',1,'RacingNode']]]
];
