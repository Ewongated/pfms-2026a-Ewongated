var indexSectionsWithContent =
{
  0: "abceghilmnoprstvwy~",
  1: "lr",
  2: "g",
  3: "glmr",
  4: "ceglmnoprsty~",
  5: "abcghlmoprstvw",
  6: "m",
  7: "cit"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator"
};

