var searchData=
[
  ['collectwallreadings_3',['collectWallReadings',['../classLaserProcessing.html#ab21b4e42db031f885382cecb4d4ff216',1,'LaserProcessing']]],
  ['complete_4',['COMPLETE',['../racingnode_8h.html#a41996d054b08274f9f7425838ce0827fa3de44296982e58199afc513a715b12ba',1,'racingnode.h']]],
  ['computealpha_5',['computeAlpha',['../classRacingNode.html#ac19567c1fb8abb4f5d7a9c34f84da0b4',1,'RacingNode']]],
  ['control_5fhz_6',['CONTROL_HZ',['../classRacingNode.html#a31c49111dfb98172439e9840746c1f44',1,'RacingNode']]],
  ['controlloop_7',['controlLoop',['../classRacingNode.html#acbff5497b40916f2855c9c43b169516d',1,'RacingNode']]],
  ['controlthread_5f_8',['controlThread_',['../classRacingNode.html#a216226cbd8bdad72dbc31618e8facc43',1,'RacingNode']]],
  ['corner_5falpha_5frad_9',['CORNER_ALPHA_RAD',['../classRacingNode.html#a404e7884ffab19d59e4247bc14fb0cdb',1,'RacingNode']]],
  ['corner_5fbrake_10',['CORNER_BRAKE',['../classRacingNode.html#a8ee01f8eb393031af3b4eeeffe76b54e',1,'RacingNode']]],
  ['corridor_5ftolerance_5fm_11',['CORRIDOR_TOLERANCE_M',['../classLaserProcessing.html#a0d663af81ad8f2295bfebdcde5abe58a',1,'LaserProcessing']]],
  ['countsegments_12',['countSegments',['../classLaserProcessing.html#ace47366d06cba8366e2aa06d2a1d7822',1,'LaserProcessing']]],
  ['cruise_5flookahead_5fdist_5fm_13',['CRUISE_LOOKAHEAD_DIST_M',['../classRacingNode.html#af9006c9fc4e3ee25a512599308aa3014',1,'RacingNode']]],
  ['cruise_5fthrottle_14',['CRUISE_THROTTLE',['../classRacingNode.html#af5153644986667dd0b4c8026a29dd9fd',1,'RacingNode']]],
  ['cruising_15',['CRUISING',['../racingnode_8h.html#a41996d054b08274f9f7425838ce0827fa1cabe08d1130fd5e925dcdc5c274d2a2',1,'racingnode.h']]],
  ['currentgoal_5f_16',['currentGoal_',['../classRacingNode.html#af04fe621b83ad7c549d56fa760265e07',1,'RacingNode']]]
];
