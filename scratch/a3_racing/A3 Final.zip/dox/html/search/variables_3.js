var searchData=
[
  ['goals_5f_143',['goals_',['../classRacingNode.html#a80aa5b0eeb7b36ddbf791a24da5d3ef4',1,'RacingNode']]],
  ['goaltolerance_5f_144',['goalTolerance_',['../classRacingNode.html#a4329bec220d15e12ac60124cda35c5c5',1,'RacingNode']]]
];
